-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2018 at 03:40 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartlibrary`
--

-- --------------------------------------------------------

--
-- Table structure for table `admincodes`
--

CREATE TABLE `admincodes` (
  `id` int(11) NOT NULL,
  `code` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admincodes`
--

INSERT INTO `admincodes` (`id`, `code`) VALUES
(1, 3009),
(2, 9009),
(3, 6009),
(4, 3222),
(5, 7007),
(6, 7008),
(7, 8009),
(8, 900009);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(20) NOT NULL,
  `cname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cname`) VALUES
(1, 'Phycis'),
(2, 'Math'),
(3, 'Programming'),
(4, 'English'),
(5, 'Electrical & Electronics Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `search`
--

CREATE TABLE `search` (
  `id` int(20) NOT NULL,
  `searchItem` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search`
--

INSERT INTO `search` (`id`, `searchItem`, `username`) VALUES
(1, 'Signal & System', 'joydas'),
(2, 'Engineering Mathematics 3', 'sou'),
(3, 'Introduction to Computer Programming', 'sou'),
(4, 'Introduction to Computer Programming', 'sou'),
(5, 'Introduction to Computer Programming', 'sou'),
(6, 'Operating System Concept', 'sou'),
(7, 'Engineering Physics 2', 'sou'),
(8, 'Engineering Mathematics 3', 'sou'),
(9, 'Engineering Physics 2', 'joydas'),
(10, 'Operating System Concept', 'joydas'),
(11, 'Operating System Concept', 'joydas'),
(12, 'Operating System Concept', 'joydas'),
(13, 'Engineering', 'sou'),
(14, 'Engineering Physics 2', 'sou');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id`, `name`) VALUES
(1, '1st'),
(2, '2nd'),
(3, '3rd'),
(4, '4th'),
(5, '5th'),
(6, '6th'),
(7, '7th'),
(8, '8th');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `semester` int(11) NOT NULL,
  `category` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `sname`, `semester`, `category`) VALUES
(1, 'Electric Circuit', 1, 5),
(3, 'Signal & System', 4, 5),
(5, 'Introduction to Computer Programming', 1, 3),
(6, 'Engineering Mathematics 1', 1, 2),
(7, 'Engineering Physics 1', 1, 1),
(8, 'Introduction to English', 1, 4),
(9, 'Engineering Physics 2', 2, 1),
(10, 'Engineering Mathematics 2', 2, 2),
(11, 'Structured Programming Language', 2, 3),
(12, 'Object Oriented Programming', 3, 3),
(13, 'Engineering Mathematics 3', 3, 2),
(14, 'Machine Learning', 8, 3),
(15, 'Pattern Recognation', 8, 3),
(16, 'Operating System Concept', 6, 3);

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(30) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobileno` varchar(30) NOT NULL,
  `AC_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `name`, `username`, `password`, `email`, `mobileno`, `AC_status`) VALUES
(1, 'Joy Das Shanta', 'joydas', 'pass', 'mail@mail.com', '1831586368', 1),
(2, 'Sourav Chackroborty', 'sou', 'pass', 'mail@mail.com', '9876', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admincodes`
--
ALTER TABLE `admincodes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `search`
--
ALTER TABLE `search`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `semester` (`semester`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`,`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admincodes`
--
ALTER TABLE `admincodes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `search`
--
ALTER TABLE `search`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`category`) REFERENCES `category` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
